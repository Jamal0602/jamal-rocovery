"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Header from "@/components/header"
import Hero from "@/components/hero"
import Footer from "@/components/footer"
import FeaturedPosts from "@/components/featured-posts"
import FeaturedProjects from "@/components/featured-projects"
import FeaturedVideos from "@/components/featured-videos"
import SkillsShowcase from "@/components/skills-showcase"
import ContactCTA from "@/components/contact-cta"
import { useOffline } from "@/hooks/use-offline"
import OfflinePage from "@/components/offline-page"
import { supabase } from "@/lib/supabase"
import { useApp } from "@/contexts/app-context"
import PhotoFrame from "@/components/photo-frame"

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [skills, setSkills] = useState([])
  const isOffline = useOffline()
  const { fetchProfile } = useApp()

  useEffect(() => {
    setIsLoaded(true)
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      // Fetch profile data
      await fetchProfile()

      // Fetch skills data from Supabase
      const { data: skillsData, error: skillsError } = await supabase
        .from("skills_star")
        .select("*")
        .order("proficiency", { ascending: false })

      if (skillsData && !skillsError) {
        setSkills(skillsData)
      } else {
        // Fallback skills data
        setSkills([
          { id: 1, name: "JavaScript", category: "Programming", proficiency: 5 },
          { id: 2, name: "React", category: "Frontend", proficiency: 4 },
          { id: 3, name: "Node.js", category: "Backend", proficiency: 4 },
          { id: 4, name: "HTML/CSS", category: "Frontend", proficiency: 5 },
          { id: 5, name: "UI/UX Design", category: "Design", proficiency: 4 },
          { id: 6, name: "IoT Development", category: "Hardware", proficiency: 4 },
          { id: 7, name: "Arduino", category: "Hardware", proficiency: 5 },
          { id: 8, name: "Problem Solving", category: "Soft Skills", proficiency: 5 },
          { id: 9, name: "Project Management", category: "Soft Skills", proficiency: 4 },
        ])
      }
    } catch (error) {
      console.error("Error fetching data:", error)
    }
  }

  if (isOffline) {
    return <OfflinePage />
  }

  return (
    <motion.main
      className="min-h-screen flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Header />
      <div className="flex-1">
        <Hero />
        <FeaturedPosts />
        <FeaturedVideos />
        <FeaturedProjects />
        <PhotoFrame />
        <SkillsShowcase skills={skills} />
        <ContactCTA />
      </div>
      <Footer />
    </motion.main>
  )
}

