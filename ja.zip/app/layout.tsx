import type React from "react"
import type { Metadata } from "next"
import ClientLayout from "./client"

export const metadata: Metadata = {
  title: "Jamal Asraf | Since 2008",
  description: "Personal portfolio of Jamal Asraf, founder of Cubiz Group's of Technology",
  icons: {
    icon: "https://file.cubiz.space/logo/png/ja.jpg",
    apple: "https://file.cubiz.space/logo/png/ja.jpg",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <ClientLayout>{children}</ClientLayout>
}
