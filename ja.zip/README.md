# Jamal Asraf Portfolio

A modern portfolio website for Jamal Asraf, founder of Cubiz Group's of Technology. This website showcases skills, projects, and professional experience with a sleek, responsive design.

## Features

- **Modern Design**: Sleek, responsive design with glass morphism effects
- **Real-time Data**: Powered by Supabase for real-time content updates
- **Admin Panel**: Comprehensive admin dashboard for content management
- **Dark/Light Mode**: Theme toggle for user preference
- **Offline Support**: Service worker for offline functionality
- **Social Integration**: Connect with social media platforms
- **Interactive UI**: Animations and transitions for enhanced user experience

## Tech Stack

- **Frontend**: Next.js, React, TypeScript, Tailwind CSS
- **UI Components**: shadcn/ui
- **Animation**: Framer Motion
- **Database**: Supabase
- **Authentication**: Custom authentication with Supabase
- **Deployment**: Vercel

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Supabase account

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/portfolio.git
   cd portfolio

